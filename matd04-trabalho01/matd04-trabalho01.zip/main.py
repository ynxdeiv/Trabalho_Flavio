from Trabalho_EDA import *

if __name__ == "__main__":
    main()